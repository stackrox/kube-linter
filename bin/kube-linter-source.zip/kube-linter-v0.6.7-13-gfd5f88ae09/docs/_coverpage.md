![logo](https://raw.githubusercontent.com/stackrox/kube-linter/main/images/logo/KubeLinter-horizontal.svg)

> Static analysis for Kubernetes YAML files and Helm charts.

<div> Made with <div class="heart"></div> by <a href = "https://stackrox.com/">StackRox</a></div>

[GitHub](https://github.com/stackrox/kube-linter)
[Get Started](README)