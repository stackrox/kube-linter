package e2etests

// Empty file with no build tag to keep the Go compiler happy.
