package templates

//go:generate go run ./codegen
