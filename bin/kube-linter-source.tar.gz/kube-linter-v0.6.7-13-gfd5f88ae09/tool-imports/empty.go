package toolimports

// Empty file to ensure that this directory has at least one Go file even without build tags.
