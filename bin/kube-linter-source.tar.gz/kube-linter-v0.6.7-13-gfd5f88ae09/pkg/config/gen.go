package config

//go:generate go run ./codegen flags.go
